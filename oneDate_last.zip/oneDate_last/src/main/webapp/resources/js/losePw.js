$(document).ready(function(){
        	
    btnDisabled();
    
    $(".input_id").on('input', check);
    $(".input_email").on('input', check);
    var toggleId = false;
    var toggleMail = false;

    function check() {
        var id = $(".input_id").val();
        var email = $(".input_email").val();
        if(id.length > 0) {
            toggleId = true;
        } else {
            toggleId = false;
        }
        if(email.length > 0) {
            toggleMail = true;
        } else {
            toggleMail = false;
        }
        
        optBtn();
    }

    function optBtn() {
        if (toggleId == true && toggleMail == true) {
            btnEnabled();
        } else {
            btnDisabled();
        }
    }

    function btnDisabled() {
        $(".btn").css('background-color', '#fce8f1');
        $(".btn").attr('disabled', true);
    }

    function btnEnabled() {
        $(".btn").css('background-color', '#e33988');
        $(".btn").attr('disabled', false);
    }

    $(".input_code").on('input', checkP3);
    var toggleCode = false;

    function checkP3() {
        var code = $(".input_code").val();
        if(code.length > 0) {
            toggleCode = true;
        } else {
            toggleCode = false;
        }
        
        optBtnP3();
    }

    function optBtnP3() {
        if (toggleCode == true) {
            btnEnabled();
        } else {
            btnDisabled();
        }
    }

    $('.next').on('click', function(){
        codeCheck();
    });
      
    var key = $('#key').val();
    var testkey = "1111";
    function codeCheck() {
        var code = $(".input_code").val();
        alert(key);
        if(key != code) {
            btnDisabled();
            $(".input_code").val('').focus();
            alert('입력하신 코드가 정확하지 않습니다. 다시 시도해 주세요.');
        }
        //else {alert('인증 성공');}
    } 
        
    $('.open').on('click', function(){
        $('.click_pop').show();
        return false;
    });
    
    $(document).click(function(e){
        if(e.target.className == "click_pop"){return false;}
        $(".click_pop").hide();
    });
    
});

function sendCode(){
	var id = $('#id').val();
    var email = $('#email_val').val();
    alert(id + ", " + email);
    $.ajax({
        type: 'POST',
        url: 'pwSendCode',
        data: {
            'id' : id,
            'email' : email
        },
        success: function(data){
        	alert('이메일 재발송!');
        }
    });
}

function openWindow(url){
    var popWidth = 500;  
    var popHeight = 550;  
    var left = Math.ceil((window.screen.width - popWidth)/2);
    var top = Math.ceil((window.screen.height - popHeight)/2);
    window.open(url, 'popup_test', 'top=' + top + ', left=' + left + 
            ', height=' + popHeight + ', width=' + popWidth);
}
