$(document).ready(function(){
        	
    btnDisabled();
    
    $(".input_id").on('input', check);
    $(".input_pw").on('input', check);
    var toggleId = false;
    var togglePw = false;

    function check() {
        var id = $(".input_id").val();
        var pw = $(".input_pw").val();
        if(id.length > 0) {
            toggleId = true;
        } else {
            toggleId = false;
        }
        if(pw.length > 0) {
            togglePw = true;
        } else {
            togglePw = false;
        }
        
        optBtn();
    }

    function optBtn() {
        if (toggleId == true && togglePw == true) {
            btnEnabled();
        } else {
            btnDisabled();
        }
    }

    function btnDisabled() {
        $(".btn").css('background-color', '#fce8f1');
        $(".btn").attr('disabled', true);
    }

    function btnEnabled() {
        $(".btn").css('background-color', '#e33988');
        $(".btn").attr('disabled', false);
    }
    
});

function openWindow(url){
    var popWidth = 500;  
    var popHeight = 550;  
    var left = Math.ceil((window.screen.width - popWidth)/2);
    var top = Math.ceil((window.screen.height - popHeight)/2);
    window.open(url, 'popup_test', 'top=' + top + ', left=' + left + 
            ', height=' + popHeight + ', width=' + popWidth);
}
