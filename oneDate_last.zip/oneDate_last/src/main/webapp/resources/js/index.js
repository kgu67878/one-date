$(document).ready(function(){

    ////////////////////////////////// start - INDEX /////////////////////////////////
        var imgArr = ['resources/images/2.jpg', 'resources/images/3.jpg', 
            'resources/images/4.jpeg', 'resources/images/1.jpg'];
        var i = 0;
        setInterval(function() {
            $(".container").css("background-image", "url(" + imgArr[i] + ")");
            i++;
            if(i >= imgArr.length){i = 0;}
        }, 3000);

        $('input').keydown(function(){
            if(event.keyCode === 13){
                event.preventDefault();
            }
        });
        
        $('.signup').on('click', function(){
            $('.p1').show();
            $('.dim').show();
            btnDisabled();
            return false;
        });
        
        $('body').click(function(e){
            if(!$('.pContainer').has(e.target).length){ 
                $('.popup').hide();
                $('.dim').hide();
            }
        });
        
        // $('.close_btn').on('click', function(){
        //     $('.popup').hide();
        //     $('.dim').hide();
        //     return false;
        // });
        
        function btnDisabled() {
            $(".btn").css('background-color', '#fce8f1');
            $(".btn").attr('disabled', true);
        }
    
        function btnEnabled() {
            $(".btn").css('background-color', '#e33988');
            $(".btn").attr('disabled', false);
        }
        
    ////////////////////////////////// end - INDEX /////////////////////////////////
        
        
    ///////////////////////////////// start - popup1 ///////////////////////////////
        
        $('.n1').on('click', function(){
            $('.p1').hide();
            $('.p2').show();
            btnDisabled();
            return false;
        });

        $("#user_name").on('input', checkP1);
        $("#user_mail").on('input', checkP1);
        var toggleName = false;
        var toggleMail = false;

        function checkP1() {
            var name = $("#user_name").val();
            var email = $("#user_mail").val();
            if(name.length > 0) {
                toggleName = true;
            } else {
                toggleName = false;
            }
            if(chkEmail(email)) {
                toggleMail = true;
            } else {
                toggleMail = false;
            }
            
            optBtnP1();
        }

        $("#user_name").on('keyup', function(){
            var name = $('#user_name').val();
            $('#count').html(name.length);
            if(name.length > 50) {
                $(this).val(name.substring(0, 50));
                $('#count').html("50");
            }
            else if($.trim(name).length == 0) {
                $('#text1').css('color', '#e02460');
                $('#msg1').css('color', '#e02460');
                $('#msg1').html("이름을 입력해 주세요.");
            }
            else if($.trim(name).length > 0) {
                $('#text1').css({ color: '#657685' });
                $('#msg1').html("");
            } 
        });

        $("#user_mail").on('keyup', function(){
            var email = $('#user_mail').val();
            if(chkEmail(email)) {	
                $('#msg2').html("");
                $('#text2').css('color', '#657685');		
                $.ajax({
                    type: 'POST',
                    url: 'checkEmail',
                    data: {
                        'email' : email
                    },
                    success: function(data){
                        if($.trim(data) != 0){
                            $('#text2').css('color', '#e02460');
                            $('#msg2').css('color', '#e02460');
                            $('#msg2').html("이미 등록된 이메일입니다.");
                            btnDisabled();
                        }
                    }
                });

                //btnEnabled();
            } else if($.trim(email).length == 0) {
                $('#user_mail').focus();
                $('#text2').css({ color: '#657685' });
                $('#msg2').html("");
                btnDisabled();
            } else {
                $('#text2').css('color', '#e02460');
                $('#msg2').css('color', '#e02460');
                $('#msg2').html("올바른 이메일을 입력해 주세요.");
                btnDisabled();
            }
        });

        function chkEmail(email) {
            var regExp = /^[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_\.]?[0-9a-zA-Z])*\.[a-zA-Z]{2,3}$/i;      
            if (regExp.test(email)) { return true; }
            else { return false; }
        }
        
        function optBtnP1() {
            if (toggleName == true && toggleMail == true) {
                btnEnabled();
                //formSubmit();
            } else {
                btnDisabled();
            }
        }

    //////////////////////////////// end - popup1 ///////////////////////////////
        
        
    //////////////////////////////// start - popup2 ///////////////////////////////
        
        $('.join').on('click', function(){
            $('.p2').hide();
            $('.p3').show();
            btnDisabled();
            sendCode();
            var email = $('#user_mail').val();
            $("#email_val").html(email);
            return false;
        });

        $('input:checkbox[name="chk"]').on('click',function(){
            var checkCoutn = $('input:checkbox[name="chk"]:checked').length;
            if(checkCoutn == 4){
                btnEnabled();
            } else{
                btnDisabled();
            }
        });

    //////////////////////////////// end - popup2 ///////////////////////////////
        
        
    //////////////////////////////// start - popup3 ///////////////////////////////
        
        var email = $('#user_mail').val();
        $("#email_val").html(email);
        
        $("#email_code").on('input', checkP3);
        var toggleCode = false;
    
        function checkP3() {
            var code = $("#email_code").val();
            if(code.length > 0) {
                toggleCode = true;
            } else {
                toggleCode = false;
            }
            
            optBtnP3();
        }
    
        function optBtnP3() {
            if (toggleCode == true) {
                btnEnabled();
            } else {
                btnDisabled();
            }
        }

        $('.err').hide();
        $('.n3').on('click', function(){
            codeCheck();
        });
         
        var testkey = "1111";
        function codeCheck() {
           var code = $("#email_code").val();
           var key = $('#key').val();		
           if(key != code) {
               btnDisabled();
               $("#email_code").val('').focus();
               $('.err').show();
               setTimeout(function() {
                   $('.err').hide();
               }, 3000);
           }
           //else {alert('인증 성공');}
        } 
         
        $('.open').on('click', function(){
            $('.click_pop').show();
            return false;
        });
        
        $(document).click(function(e){
            if(e.target.className == "click_pop"){return false;}
            $(".click_pop").hide();
        });

        
    //////////////////////////////// end - popup3 ///////////////////////////////

    }); // end - $(document).ready

    function openWindow(url){
        var popWidth = 500;  
        var popHeight = 550;  
        var left = Math.ceil((window.screen.width - popWidth)/2);
        var top = Math.ceil((window.screen.height - popHeight)/2);
        window.open(url, 'popup_test', 'top=' + top + ', left=' + left + 
                ', height=' + popHeight + ', width=' + popWidth);
    }
    
    function sendCode(){
        var email = $('#user_mail').val();
        $.ajax({
            type: 'POST',
            url: 'sendCode',
            data: {
                'email' : email
            },
            success: function(data){
                //alert(data);
                $('#key').val(data);
            }
        });
    }
    
    function emailModify(){
        $('.p3').hide();
        $('.p1').show();
    }

    function formSubmit() {
        if (grecaptcha.getResponse() == ""){
            alert("자동등록 방지에 체크해 주세요.");
            return false;
        } else {
            //btnEnabled();
            return true;
        }
    }
    
    
    