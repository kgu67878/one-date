$(document).ready(function(){

//	widnow.resizeTo(screen.availWidth, screen.availHeight);
	
    $('.n4').on('click', function(){
        $('.p4').hide();
        $('.dim').hide();
        return false;
    });
    
    $('body').click(function(e){
        if(!$('.popup').has(e.target).length){ 
            $('.popup').hide();
            $('.dim').hide();
        }
    });

    $("#user_id").on('keyup', function(){
        var id = $('#user_id').val();
        if(chkId(id)) {	
            $('#msg3').html("");
            $.ajax({
                type: 'POST',
                url: 'checkId',
                data: {
                    'id' : id
                },
                success: function(data){
                    if($.trim(data) != 0){
                        $('#msg3').css('color', '#e02460');
                        $('#msg3').html("이미 등록된 아이디입니다.");
                    }
                    //$('#msg3').html("사용 가능한 아이디입니다.");
                }
            });
        } else {
            $('#msg3').css('color', '#e02460');
            $('#msg3').html("아이디는 영문으로 6자 이상이어야 합니다.");
        }
    });

    $("#user_pw").on('keyup', function(){
        var password = $('#user_pw').val();
        if (chkPw(password)) {
            $('#msg2').html("");
        }
        else {
            $('#msg2').css('color', '#e02460');
            $('#msg2').html("보안 수준이 더 강력한 비밀번호를 입력해주세요.");
        }
    });

    $('.pw_toggle').on('click', function(){
        $('input').toggleClass('active');
        if ($('input').hasClass('active')) {
            $('#user_pw').attr('type', 'text');
            $(this).html("비밀번호 숨기기");
        } else {
            $('#user_pw').attr('type', 'password');
            $(this).html("비밀번호 보기");
        }
    });
    
    $('.birth').on('input', function(){
        var year = $('#birth_y').val();
        var month = $('#birth_m').val();
        var day = $('#birth_d').val();
        var month = (month.length == 1) ? "0" + month : month;
        var day = (day.length == 1) ? "0" + day : day;
        var str = year + month + day;
        $('#birth_day').val(str);
    });
    
    $("#chkSms").change(function(){
        if($("#chkSms").is(":checked")){
            $("#chkSms").val('1');
        }else{
            $("#chkSms").val('0');
        }
    });
    
    $('.hb').on('click', function(){
        $('.p5').show();
        $('.dim').show();
        $('.str_box').show();
        return false;
    });

    $('.n5').on('click', function(){
        $('.p5').hide();
        $('.dim').hide();
        return false;
    });

    var i = 0;
    $('.sel').on('click', function(){
        var color = $(this).css('color');
        if(i < 5){
            if(color == "rgb(227, 57, 136)"){
                var hobby = $('#hobby').val() + $(this).val() + " / ";
                $(this).css({
                    'background-color' : '#e33988',
                    'color' : '#fff'
                });
                $('#hobby').val(hobby);
                i++;
                //alert("$(this):"+$(this).css("color"));
                $('#count').html(i);
            } else {
                $(this).css({
                    'background-color' : '#fff',
                    'color' : '#e33988'
                });
                i--;
                //alert("$(this):"+$(this).css("color"));
                var str1 = $(this).val() + " / ";
                var str2 = $('#hobby').val();
                var str3 = str2.replace(str1, "");
                $('#hobby').val(str3);
                $('#count').html(i);
            }
        }
        else if(i == 5 && color == "rgb(255, 255, 255)") {
            $(this).css({
                'background-color' : '#fff',
                'color' : '#e33988'
            });
            i--;
            //alert("$(this):"+$(this).css("color"));
            var str1 = $(this).val() + " / ";
            var str2 = $('#hobby').val();
            var str3 = str2.replace(str1, "");
            $('#hobby').val(str3);
            $('#count').html(i);
        }
    });
    
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#img1').attr('src', e.target.result); 
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInput1").change(function(){
        readURL(this);
        $('.sec1').show();
    });
    $("#imgInput2").change(function(){
        readURL(this);
        $('.sec2').show();
    });
    $("#imgInput3").change(function(){
        readURL(this);
        $('.sec3').show();
    });
    $("#imgInput4").change(function(){
        readURL(this);
        $('.sec4').show();
    });

    /////////////////////////////////////////////////////////////////////////
    
//    btnDisabled();
//    
//    $("#user_name").on('input', check);
//    $("#user_id").on('input', check);
//    $("#user_pw").on('input', check);
//    //$(".birth").on('input', check);
//    $("#phone").on('input', check);
//    var toggleName = false;
//    var toggleId = false;
//    var togglePw = false;
//    //var toggleBirth = false;
//    var togglePhone = false;
//
//    function check() {
//        var name = $("#user_name").val();
//        var id = $("#user_id").val();
//        var pw = $("#user_pw").val();
//        var phone = $("#phone").val();
//        if(name.length > 0) {
//            toggleName = true;
//        } else {
//            toggleName = false;
//        }
//        if(id.length > 0) {
//            toggleId = true;
//        } else {
//            toggleId = false;
//        }
//        if(pw.length > 0) {
//            togglePw = true;
//        } else {
//            togglePw = false;
//        }
//        if(phone.length > 0) {
//            togglePhone = true;
//        } else {
//            togglePhone = false;
//        }
//        
//        optBtn();
//    }

});
///////////////////////////////////////////////////////////////////////////

function optBtn() {
    if (toggleName == true && toggleId == true && 
            togglePw == true && togglePhone == true) {
        btnEnabled();
    } else {
        btnDisabled();
    }
}

function btnDisabled() {
    $(".save").css('background-color', '#fce8f1');
    $(".save").attr('disabled', true);
}

function btnEnabled() {
    $(".save").css('background-color', '#e33988');
    $(".save").attr('disabled', false);
}

function chkId(id) {
    var idReg = /^[A-za-z0-9]{6,15}/g;;
    if (idReg.test(id)) return true;
    else return false;
}

function chkPw(password) {
    var pwReg = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,15}$/;
    if (pwReg.test(password)) return true;
    else return false;
}

function goPopup(){
    // 주소검색을 수행할 팝업 페이지를 호출합니다.
    // 호출된 페이지(jusopopup.jsp)에서 실제 주소검색URL(http://www.juso.go.kr/addrlink/addrLinkUrl.do)를 호출하게 됩니다.
    var pop = window.open("resources/popup/jusoPopup.jsp","pop","width=570,height=420, scrollbars=yes, resizable=yes"); 
    
    // 모바일 웹인 경우, 호출된 페이지(jusopopup.jsp)에서 실제 주소검색URL(http://www.juso.go.kr/addrlink/addrMobileLinkUrl.do)를 호출하게 됩니다.
    //var pop = window.open("/popup/jusoPopup.jsp","pop","scrollbars=yes, resizable=yes"); 
}
function jusoCallBack(roadFullAddr){
        // 팝업페이지에서 주소입력한 정보를 받아서, 현 페이지에 정보를 등록합니다.	
        $('#address').val(roadFullAddr);		
}

